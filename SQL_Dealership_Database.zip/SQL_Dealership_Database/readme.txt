Description:
This project is meant to be a demonstration of database management using Java and the Java.SQL library. 
The Java program can run a total of six SQL queries. All data seen within the project is mock data.

Instructions:
1. Import the dealershipnetwork file into My SQL Workbench.
2. Import all .CSV files into the dealershipnetwork database
3. Run program.